@extends('layouts.admin.app')
@section('title', $title)
@section('content')
    <div >
        <div >
            <div class="page-header">
                <div class="page-block mb-3">
    <div class="row align-items-center">
        <div class="col-md-12">
            <div class="page-header-title">
                <h2 class="mb-0">USERS LIST</h2>
                <p class="text-muted">Manage your users</p>
            
                
            </div>
        </div></div>
</div>
                {{-- <div class="page-btn">
                    <a href="{{ route('admin.users.create') }}" class="btn btn-success">
                        <i class="ti ti-plus me-1"></i>Add New User
                    </a>
                </div> --}}
            </div>

            <div class="card overflow-hidden shadow-sm border border-dashed">
                <div class="card-body px-0 py-0">
                    <form class="p-3 bg-auto-subtle border-bottom" action="{{ route('admin.users.index') }}" method="GET">
                        <div class="row align-items-center g-2">
                            <div class="col-md-2">
                                <select name="per_page" class="form-select form-select-sm" onchange="this.form.submit()">
                                    <option value="">--Hiển thị--</option>
                                    <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10</option>
                                    <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25</option>
                                    <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50</option>
                                    <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>100</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="text" name="search" class="form-control form-control-sm" placeholder="Tìm kiếm username, email, ip..." value="{{ request('search') }}">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="start_date" class="form-control form-control-sm" value="{{ request('start_date') }}">
                            </div>
                            <div class="col-md-2">
                                <input type="date" name="end_date" class="form-control form-control-sm" value="{{ request('end_date') }}">
                            </div>
                            <div class="col-md-3 d-flex gap-2">
                                <button type="submit" class="btn btn-sm btn-primary w-100">
                                    <i class="ti ti-search me-1"></i> Tìm kiếm
                                </button>
                                <a href="{{ route('admin.users.index') }}" class="btn btn-sm btn-light-danger w-100">
                                    <i class="ti ti-trash me-1"></i> Bỏ lọc
                                </a>
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-hover table-borderless align-middle mb-0 text-nowrap w-100">
                            <thead class="bg-light-subtle text-muted">
                                <tr>
                                    <th class="text-center" style="width: 50px;">
                                        <div class="form-check m-0 d-flex justify-content-center">
                                            <input class="form-check-input" type="checkbox" id="select-all">
                                        </div>
                                    </th>
                                    <th class="text-uppercase small">ID</th>
                                    <th class="text-uppercase small">Tài khoản</th>
                                    <th class="text-uppercase small">Email</th>
                                    <th class="text-uppercase small">Cấp bậc</th>
                                    <th class="text-uppercase small">Số dư</th>
                                    <th class="text-uppercase small">Tổng nạp</th>
                                    <th class="text-uppercase small">Trạng thái</th>
                                    <th class="text-uppercase small">IP</th>
                                    <th class="text-uppercase small">Ngày tạo</th>
                                    <th class="text-uppercase small text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($users as $user)
                                    <tr>
                                        <td class="text-center">
                                            <div class="form-check m-0 d-flex justify-content-center">
                                                <input class="form-check-input" type="checkbox" value="{{ $user->id }}">
                                            </div>
                                        </td>
                                        <td><span class="text-muted">{{ $user->id }}</span></td>
                                        <td><span class="fw-medium text-primary">{{ $user->username }}</span></td>
                                        <td><span class="text-muted">{{ $user->email }}</span></td>
                                        <td>
                                            @if($user->role == 'admin')
                                                <span class="badge bg-light-primary text-primary px-2 py-1">Admin</span>
                                            @elseif($user->role == 'dev')
                                                <span class="badge bg-light-info text-info px-2 py-1">Dev</span>
                                            @else
                                                <span class="badge bg-light-secondary text-secondary px-2 py-1">Member</span>
                                            @endif
                                        </td>
                                        <td><span class="fw-semibold text-success">{{ number_format($user->balance) }}đ</span></td>
                                        <td><span class="fw-medium">{{ number_format($user->total_deposited) }}đ</span></td>
                                        <td>
                                            @if($user->banned)
                                                <span class="badge bg-light-danger text-danger px-2 py-1 border border-danger border-opacity-25">Banned</span>
                                            @else
                                                <span class="badge bg-light-success text-success px-2 py-1 border border-success border-opacity-25">Active</span>
                                            @endif
                                        </td>
                                        <td><span class="text-muted small">{{ $user->ip_address }}</span></td>
                                        <td><span class="text-muted small">{{ $user->created_at->format('d/m/Y') }}</span></td>
                                        <td class="text-center">
                                            <a class="me-2 text-primary" href="{{ route('admin.users.show', $user->id) }}">
                                                <i class="ti ti-edit fs-5"></i>
                                            </a>
                                            <a class="text-danger confirm-delete" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#deleteModal" data-id="{{ $user->id }}">
                                                <i class="ti ti-trash fs-5"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="11">
                                            <div class="text-center py-5">
                                                <svg style="width: 184px; height: 152px;" viewBox="0 0 184 152" xmlns="http://www.w3.org/2000/svg">
                                                    <g fill="none" fill-rule="evenodd">
                                                        <g transform="translate(24 31.67)">
                                                            <ellipse fill-opacity=".8" fill="#F5F5F7" cx="67.797" cy="106.89" rx="67.797" ry="12.668"></ellipse>
                                                            <path d="M122.034 69.674L98.109 40.229c-1.148-1.386-2.826-2.225-4.593-2.225h-51.44c-1.766 0-3.444.839-4.592 2.225L13.56 69.674v15.383h108.475V69.674z" fill="#AEB8C2"></path>
                                                            <path d="M33.83 0h67.933a4 4 0 0 1 4 4v93.344a4 4 0 0 1-4 4H33.83a4 4 0 0 1-4-4V4a4 4 0 0 1 4-4z" fill="#F5F5F7"></path>
                                                            <path d="M42.678 9.953h50.237a2 2 0 0 1 2 2V36.91a2 2 0 0 1-2 2H42.678a2 2 0 0 1-2-2V11.953a2 2 0 0 1 2-2zM42.94 49.767h49.713a2.262 2.262 0 1 1 0 4.524H42.94a2.262 2.262 0 0 1 0-4.524zM42.94 61.53h49.713a2.262 2.262 0 1 1 0 4.525H42.94a2.262 2.262 0 0 1 0-4.525zM121.813 105.032c-.775 3.071-3.497 5.36-6.735 5.36H20.515c-3.238 0-5.96-2.29-6.734-5.36a7.309 7.309 0 0 1-.222-1.79V69.675h26.318c2.907 0 5.25 2.448 5.25 5.42v.04c0 2.971 2.37 5.37 5.277 5.37h34.785c2.907 0 5.277-2.421 5.277-5.393V75.1c0-2.972 2.343-5.426 5.25-5.426h26.318v33.569c0 .617-.077 1.216-.221 1.789z" fill="#DCE0E6"></path>
                                                        </g>
                                                        <path d="M149.121 33.292l-6.83 2.65a1 1 0 0 1-1.317-1.23l1.937-6.207c-2.589-2.944-4.109-6.534-4.109-10.408C138.802 8.102 148.92 0 161.402 0 173.881 0 184 8.102 184 18.097c0 9.995-10.118 18.097-22.599 18.097-4.528 0-8.744-1.066-12.28-2.902z" fill="#DCE0E6"></path>
                                                    </g>
                                                </svg>
                                                <p class="mt-3 text-muted">Không tìm thấy dữ liệu</p>
                                            </div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    
                   @if($users->hasPages())
    <div class="d-flex justify-content-end p-3 border-top">
        {{ $users->withQueryString()->links('pagination::bootstrap-5') }}
    </div>
@endif
                </div>
            </div>

        </div>
    </div>


    <x-modal-confirm-delete
        message="Bạn có chắc chắn muốn xóa người dùng này không? Tất cả dữ liệu có liên quan đến nó sẽ
            biến mất khỏi hệ thống!" />


@endsection
@push('scripts')
    <script>
        $(document).ready(function() {
            let userId;

            // Lưu ID user khi click nút xóa
            $('.confirm-delete').on('click', function() {
                userId = $(this).data('id');
            });

            // Xử lý sự kiện click nút xác nhận xóa
            $('#confirmDelete').on('click', function() {
                $.ajax({
                    url: '/admin/users/delete/' + userId,
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        $('#deleteModal').modal('hide');
                        if (response.success) {
                            // Hiển thị thông báo thành công
                            Swal.fire({
                                icon: 'success',
                                title: 'Thành công!',
                                text: 'Đã xóa người dùng thành công',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                // Reload trang
                                window.location.reload();
                            });
                        } else {
                            // Hiển thị thông báo lỗi
                            Swal.fire({
                                icon: 'error',
                                title: 'Lỗi!',
                                text: response.message ||
                                    'Có lỗi xảy ra khi xóa người dùng',
                            });
                        }
                    },
                    error: function(xhr) {
                        $('#deleteModal').modal('hide');
                        // Hiển thị thông báo lỗi
                        Swal.fire({
                            icon: 'error',
                            title: 'Lỗi!',
                            text: 'Có lỗi xảy ra khi xóa người dùng',
                        });
                    }
                });
            });
        });
    </script>
@endpush
