<?php
namespace App\Http\Controllers\User;
use App\Http\Controllers\Controller;

use App\Models\GameAccount;
use App\Models\MoneyTransaction;
use App\Models\PurchaseHistory;
use App\Models\User;
use App\Models\DiscountCode;
use App\Http\Controllers\DiscountCodeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class GameAccountController extends Controller
{
    public function show($id)
    {
        $account = GameAccount::findOrFail($id);

        $images = json_decode($account->images) ?? [];

        $flashSalePrice = \App\Models\FlashSale::getActivePrice('game', $account->game_category_id);
        if ($flashSalePrice !== null) {
            $account->price = $flashSalePrice;
            $account->is_flash_sale = true;
        }

        $relatedAccounts = GameAccount::where('game_category_id', $account->game_category_id)
            ->where('id', '!=', $account->id)
            ->where('status', 'available')
            ->orderBy('id', 'desc')
            ->take(6)
            ->get();

        return view("user.account.detail", compact('account', 'images', 'relatedAccounts'));
    }


    public function purchase(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            $account = GameAccount::where('id', $id)
                ->where('status', 'available')
                ->lockForUpdate()
                ->firstOrFail();

            $flashSalePrice = \App\Models\FlashSale::getActivePrice('game', $account->game_category_id);
            if ($flashSalePrice !== null) {
                $account->price = $flashSalePrice;
            }

            $user = Auth::user();

            // Khóa bản ghi user để đọc số dư mới nhất — chống double submission.
            $user = User::where('id', $user->id)->lockForUpdate()->firstOrFail();

            $finalPrice = $account->price;
            $discountAmount = 0;
            $discountCodeController = new DiscountCodeController();

            // Check for discount code if provided
            if ($request->filled('discount_code')) {
                $discountCode = DiscountCode::where('code', $request->discount_code)
                    ->where('is_active', '1')
                    ->first();

                if ($discountCode) {
                    // Calculate discount
                    if ($discountCode->discount_type === 'percentage') {
                        $discountAmount = ($account->price * $discountCode->discount_value) / 100;
                        // Apply max discount if set
                        if ($discountCode->max_discount_value && $discountAmount > $discountCode->max_discount_value) {
                            $discountAmount = $discountCode->max_discount_value;
                        }
                    } else {
                        $discountAmount = $discountCode->discount_value;
                    }

                    // Calculate final price
                    $finalPrice = $account->price - $discountAmount;
                    if ($finalPrice < 0) {
                        $finalPrice = 0;
                    }

                    // Apply discount code
                    if ($discountCode) {
                        // Update usage count directly in database
                        DB::table('discount_codes')
                            ->where('id', $discountCode->id)
                            ->increment('usage_count');

                        // Record usage details
                        DB::table('discount_code_usages')->insert([
                            'discount_code_id' => $discountCode->id,
                            'user_id' => $user->id,
                            'context' => 'account',
                            'item_id' => $account->id,
                            'original_price' => $account->price,
                            'discounted_price' => $finalPrice,
                            'discount_amount' => $discountAmount,
                            'used_at' => now(),
                            'created_at' => now(),
                            'updated_at' => now()
                        ]);
                    }
                }
            }

            if ($user->balance < $finalPrice) {
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Số dư không đủ để mua tài khoản này'
                ]);
            }

            // Update user balance
            $balanceBefore = $user->balance;
            $balanceAfter = $balanceBefore - $finalPrice;

            // Use direct DB update instead of model save
            DB::table('users')
                ->where('id', $user->id)
                ->update(['balance' => $balanceAfter]);

            // Update account status
            DB::table('game_accounts')
                ->where('id', $account->id)
                ->update([
                    'status' => 'sold',
                    'buyer_id' => $user->id
                ]);

            // Thêm lịch sử biến động số dư
            DB::table('money_transactions')->insert([
                'user_id' => $user->id,
                'type' => 'purchase',
                'amount' => -$finalPrice,
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'description' => 'Mua tài khoản #' . $account->id . ($discountAmount > 0 ? ' (Giảm giá: ' . number_format($discountAmount) . 'đ)' : ''),
                'reference_id' => $account->id,
                'created_at' => now(),
                'updated_at' => now()
            ]);

            // Ghi lịch sử mua hàng — nguồn dữ liệu thật cho trang "Nhận xét khách hàng".
            PurchaseHistory::create([
                'user_id' => $user->id,
                'game_account_id' => $account->id,
                'amount' => $finalPrice,
                'account_details' => json_encode([
                    'account_name' => $account->account_name,
                    'category_id' => $account->game_category_id,
                ], JSON_UNESCAPED_UNICODE),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Mua tài khoản thành công!',
                'data' => [
                    'new_balance' => $balanceAfter
                ],
                'redirect_url' => route('profile.purchased-accounts')
            ]);

        } catch (\Exception $e) {
            DB::rollBack();

            // Log đầy đủ phía server, không trả chi tiết kỹ thuật ra client.
            \Illuminate\Support\Facades\Log::error('Lỗi mua tài khoản #' . $id . ': ' . $e->getMessage(), [
                'user_id' => Auth::id(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Có lỗi xảy ra khi mua tài khoản. Vui lòng thử lại sau ít phút.'
            ]);
        }
    }
}
